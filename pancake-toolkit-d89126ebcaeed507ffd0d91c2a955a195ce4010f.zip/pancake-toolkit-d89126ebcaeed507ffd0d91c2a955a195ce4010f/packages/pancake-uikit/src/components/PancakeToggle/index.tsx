export { default as PancakeToggle } from "./PancakeToggle";
export type { PancakeToggleProps, Scales as PancakeToggleScales } from "./types";
