export { default as ThemeSwitcher } from "./ThemeSwitcher";
export type { Props as ThemeSwitcherProps } from "./ThemeSwitcher";
