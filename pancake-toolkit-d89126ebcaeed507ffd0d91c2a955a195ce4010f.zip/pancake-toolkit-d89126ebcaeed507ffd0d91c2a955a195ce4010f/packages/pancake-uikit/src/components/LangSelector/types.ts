export interface Language {
  code: string;
  language: string;
  locale: string;
}
