const SubMenuItemsMock = [
  {
    label: "Overview",
    href: "/",
  },
  {
    label: "Farms",
    href: "/",
  },
  {
    label: "Syrup Pools",
    href: "/",
  },
  {
    label: "Swap",
    href: "/swap",
    iconName: "Swap",
  },
];

export default SubMenuItemsMock;
